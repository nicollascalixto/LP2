﻿using System;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Preava0030482523017 { 

   
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnProcessar_Click(object sender, EventArgs e)
        {
        lstResultado.Items.Clear();

       
        double[] vetorA = new double[10];
        double[] vetorB = new double[10];

        string strValor;
        double dblValor;

        
        for (int intIndice = 0; intIndice < vetorA.Length; intIndice++){
            do{
                strValor = Interaction.InputBox(
                    $"Digite o valor da posição {intIndice}:",
                    "Entrada de Dados",
                    "0");}
                
                while (!double.TryParse(strValor, out dblValor) || dblValor < 0);

            vetorA[intIndice] = dblValor;}

       
        for (int intIndice = 0; intIndice < vetorA.Length; intIndice++){
            if (intIndice % 2 == 0)
            {
                vetorB[intIndice] = vetorA[intIndice] * 4;
            }
            else
            {
                vetorB[intIndice] = vetorA[intIndice] + 4;
            }
}

           
            for (int intIndice = 0; intIndice < vetorA.Length; intIndice++){
                lstResultado.Items.Add(
                    $"Posição:{intIndice} " +
                    $"MatrizA={vetorA[intIndice].ToString("N2")} " +
                    $"MatrizB={vetorB[intIndice].ToString("N2")}");}
        }

    private void btnLimpar_Click(object sender, EventArgs e)
    {
     lstResultado.Items.Clear();
    }
}
}
